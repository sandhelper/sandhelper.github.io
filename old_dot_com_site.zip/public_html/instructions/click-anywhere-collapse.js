// JavaScript module to make the expanded mobile menu retract when the 'x-out' button is clicked (tapped),
// or when any area outside the navigation is clicked/tapped.

$(document).ready(function () {
     $(document).click(function (event) {
         var clickover = $(event.target);
         var _opened = $(".navbar-collapse").hasClass("show");
         if (_opened === true && !clickover.hasClass("navbar-toggler")) {
             $(".navbar-toggler").click();
         }
     });
    });

$(document).ready(function () {
     $(document).click(function (event) {
         var clickover = $(event.target);
         var _opened = $(".navbar-collapse").hasClass("show");
         if (_opened === true && clickover.hasClass(".menu-close")) {
             $(".navbar-toggler").click();
         }
     });
    });

