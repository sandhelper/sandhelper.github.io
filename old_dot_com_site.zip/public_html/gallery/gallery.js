$(document).ready(function () {
    $('#carouselExampleControls').on('slide.bs.carousel', function() {
        
        $('#carousel-wrapper').show();
        
//        $('.carousel').carousel(slideNum)
    });
});
$(document).ready(function () {
    $('#carousel-x').click(function() {
        
        $('#carousel-wrapper').hide();
        
        
    });
});

var imgs = ["guy-on-sand-helper-waving-to-camera.JPG","laying-on-ocmd-beach-in-front-of-sand-wheelchair_opt.JPG","sand-wheelchair-in-bethany-dune-crossing_opt.JPG","reuben-on-wheelchair-oc-boardwalk_opt.JPG","rebecca-on-electric-beach-wheelchair-33rd-street-ocmd.JPG","two-sand-wheelchairs-white-and-tan-from-behind-in-oc_opt.JPG","sand-scooter-II-in-front-of-ocean-white-iso_opt.JPG","white-sand-scooter-low-view-of-sand-tires-ocmd_opt.JPG","foot-plate-close-up-tan-wheelchair_opt.JPG","chairs-and-beach-equipment-strapped-to-back-sand-helper_opt.JPG","rueben-on-wheelchair-with-ladies-oc-md_opt.JPG","family-on-beach-sitting-in-front-of-electric-chairs_opt.JPG","IMG_3037.JPG","driving-scooter-from-sand-to-oc-boardwalk_opt.JPG","sand-helper-nick-with-governor-maryland-and-senator_opt.JPG"]

$('#modal1').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var imgsrc = button.data('imgsrc') // Extract info from data-* attributes
  var imgs = ["guy-on-sand-helper-waving-to-camera.JPG","laying-on-ocmd-beach-in-front-of-sand-wheelchair_opt.JPG","sand-wheelchair-in-bethany-dune-crossing_opt.JPG","reuben-on-wheelchair-oc-boardwalk_opt.JPG","rebecca-on-electric-beach-wheelchair-33rd-street-ocmd.JPG","two-sand-wheelchairs-white-and-tan-from-behind-in-oc_opt.JPG","sand-scooter-II-in-front-of-ocean-white-iso_opt.JPG","white-sand-scooter-low-view-of-sand-tires-ocmd_opt.JPG","foot-plate-close-up-tan-wheelchair_opt.JPG","chairs-and-beach-equipment-strapped-to-back-sand-helper_opt.JPG","rueben-on-wheelchair-with-ladies-oc-md_opt.JPG","family-on-beach-sitting-in-front-of-electric-chairs_opt.JPG","IMG_3037.JPG","driving-scooter-from-sand-to-oc-boardwalk_opt.JPG","sand-helper-nick-with-governor-maryland-and-senator_opt.JPG"]
  var imgpos = parseInt(button.data('imgpos'))
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  
  
  var modal = $(this)
  modal.find('.modalimg').attr("src", imgsrc)
  modal.find('.modalimg').attr("data-imgpos", imgpos)
})




/*$('#modal1').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget)
    var imgpos = button.data('imgpos')
    
    $.each(imgindex[imgpos])
})*/


/*$('.modal-prev').click(function(event) {
    var button = $(event.target)
    var imgpos = parseInt($('.modalimg').data('imgpos'))
    var imgs = ["guy-on-sand-helper-waving-to-camera.JPG","laying-on-ocmd-beach-in-front-of-sand-wheelchair_opt.JPG","sand-wheelchair-in-bethany-dune-crossing_opt.JPG","reuben-on-wheelchair-oc-boardwalk_opt.JPG","rebecca-on-electric-beach-wheelchair-33rd-street-ocmd.JPG","two-sand-wheelchairs-white-and-tan-from-behind-in-oc_opt.JPG","sand-scooter-II-in-front-of-ocean-white-iso_opt.JPG","white-sand-scooter-low-view-of-sand-tires-ocmd_opt.JPG","foot-plate-close-up-tan-wheelchair_opt.JPG","chairs-and-beach-equipment-strapped-to-back-sand-helper_opt.JPG","rueben-on-wheelchair-with-ladies-oc-md_opt.JPG","family-on-beach-sitting-in-front-of-electric-chairs_opt.JPG","IMG_3037.JPG","driving-scooter-from-sand-to-oc-boardwalk_opt.JPG","sand-helper-nick-with-governor-maryland-and-senator_opt.JPG"]
    
    var i
    for (i = imgpos; i < imgs.length; i++){
        if (imgpos > 0) {
          var prev = (imgpos - 1)
      }
        else {
            var prev = (15)            
        }
        var imgsrc = imgs[prev]
        
        $('#modal1').find('.modalimg').attr("src", imgsrc)
        $('#modal1').find('.modalimg').attr("data-imgpos", prev)
    }
    

    
    console.log(prev)
    
})

$('.modal-next').click( function(event) {
    var button = $(event.target)
    var imgpos = parseInt($('.modalimg').data('imgpos'))
    var imgs = ["guy-on-sand-helper-waving-to-camera.JPG","laying-on-ocmd-beach-in-front-of-sand-wheelchair_opt.JPG","sand-wheelchair-in-bethany-dune-crossing_opt.JPG","reuben-on-wheelchair-oc-boardwalk_opt.JPG","rebecca-on-electric-beach-wheelchair-33rd-street-ocmd.JPG","two-sand-wheelchairs-white-and-tan-from-behind-in-oc_opt.JPG","sand-scooter-II-in-front-of-ocean-white-iso_opt.JPG","white-sand-scooter-low-view-of-sand-tires-ocmd_opt.JPG","foot-plate-close-up-tan-wheelchair_opt.JPG","chairs-and-beach-equipment-strapped-to-back-sand-helper_opt.JPG","rueben-on-wheelchair-with-ladies-oc-md_opt.JPG","family-on-beach-sitting-in-front-of-electric-chairs_opt.JPG","IMG_3037.JPG","driving-scooter-from-sand-to-oc-boardwalk_opt.JPG","sand-helper-nick-with-governor-maryland-and-senator_opt.JPG"]
    
    var i
    for (i = imgpos; i < imgs.length; i++){
        if (imgpos < 15) {
          var next = (imgpos + 1)
      }
        else {
            var next = (0)            
        }
        var imgsrc = ims[next]
        
        $('#modal1').find('.modalimg').attr("src", imgsrc)
        $('#modal1').find('.modalimg').attr("data-imgpos", next)
    }
    
    console.log(next)
    
})*/




/*
$('.modal-next').click(function() {
    var button = $(this)
    var imgpos = parseInt(button.data('imgpos'))
    
    var imgindex = ["guy-on-sand-helper-waving-to-camera.JPG","laying-on-ocmd-beach-in-front-of-sand-wheelchair_opt.JPG","sand-wheelchair-in-bethany-dune-crossing_opt.JPG","reuben-on-wheelchair-oc-boardwalk_opt.JPG","rebecca-on-electric-beach-wheelchair-33rd-street-ocmd.JPG","two-sand-wheelchairs-white-and-tan-from-behind-in-oc_opt.JPG","sand-scooter-II-in-front-of-ocean-white-iso_opt.JPG","white-sand-scooter-low-view-of-sand-tires-ocmd_opt.JPG","foot-plate-close-up-tan-wheelchair_opt.JPG","chairs-and-beach-equipment-strapped-to-back-sand-helper_opt.JPG","rueben-on-wheelchair-with-ladies-oc-md_opt.JPG","family-on-beach-sitting-in-front-of-electric-chairs_opt.JPG","IMG_3037.JPG","driving-scooter-from-sand-to-oc-boardwalk_opt.JPG","sand-helper-nick-with-governor-maryland-and-senator_opt.JPG"]
    
    
    $('.modalimg').attr("src", imgindex[imgpos])
    $('.modal-prev').attr("data-imgsrc", x)
    $('.modal-next').attr("data-imgsrc", x)
})
*/
